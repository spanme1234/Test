# Code of Conduct
- Feel free to propose new challenges to this practice. And also join me in this road or open some Issue about anything you want to clarify about the project.
- Please be respectful with other contributors

Any doubt you can contact me in my twitter [@k30v1n](http://twitter.com/k30v1n)
