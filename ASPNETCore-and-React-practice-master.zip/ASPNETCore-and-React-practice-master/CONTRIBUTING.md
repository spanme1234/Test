# Contributing
- Please feel free to contribute with anything you like
- Be sure that what you are doing is a good challenge for practice and know (as this repo is for learning)

# Pull request messages
Please list everything you've done in your pull request. If this is not provided, the pull request will be closed.
